D2R Mobile 额外 24 个角色

原始存档作者：P3N9U1N（MIT 许可），许可原文见 SOURCE-LICENSE.txt。
来源：https://github.com/P3N9U1N/diablo2-savegames
固定来源提交：c8d3315bdeb65e72128f648a58e65dfae533495d
本次仅做格式转换、完整性检查和安装目录整理，不是这些角色的原创作者。
转换工具：ResurrectedTrader/D2SSharp 0.0.24（MIT）。

已转换为当前手机使用的格式 105 / ReignOfTheWarlock。
等级、属性、技能、任务、传送点和物品内容转换前后核对一致；长度、校验和、SHA256、二次读写一致性通过。
每个角色带主武器及头、项链、衣服、双戒指、腰带、鞋、手套；双手武器角色可能不装备盾牌。
尚需在手机实际进入游戏验收。不包含共享仓库，不覆盖原角色；无需重装应用和资源。

角色名 | 职业 | 等级 | 物品数量
Admin | 死灵法师 | 81 | 38
Anjazone | 亚马逊 | 87 | 49
Benny | 德鲁伊 | 85 | 46
Dark_Savant | 圣骑士 | 89 | 46
Eirena | 法师 | 93 | 50
Erza | 刺客 | 83 | 50
Fedora | 死灵法师 | 86 | 45
Heizi | 死灵法师 | 90 | 46
Heizia | 法师 | 86 | 52
Hotman | 德鲁伊 | 84 | 53
Joanna | 亚马逊 | 84 | 45
Lyndon | 野蛮人 | 84 | 53
Miriam | 法师 | 90 | 44
Mule_abcd | 刺客 | 87 | 53
Naofumi | 圣骑士 | 81 | 48
Natsu | 德鲁伊 | 84 | 43
Raphtalia | 法师 | 85 | 48
Ravena | 刺客 | 85 | 58
Saitama | 野蛮人 | 81 | 44
Thomas | 圣骑士 | 85 | 47
Torque | 野蛮人 | 82 | 42
Tux | 野蛮人 | 87 | 43
Vegeta | 圣骑士 | 86 | 46
Zenwalker | 野蛮人 | 88 | 47

导入前必须保存并退出游戏，并完整备份当前手机存档；发生同名冲突时停止，不覆盖。
将各角色目录追加到 Documents/save/，逐个读回核对 SHA256，并确认原有存档保持不变。
